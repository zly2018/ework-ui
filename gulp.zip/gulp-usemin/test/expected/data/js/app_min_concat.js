var sample=111;
console.log(sample);