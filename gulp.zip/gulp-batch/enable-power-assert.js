require('espower-loader')({
    cwd: process.cwd(),
    pattern: 'test/*.js'
});
